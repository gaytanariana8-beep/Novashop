<?php
// login.php - API para iniciar sesión

require_once 'config.php';

// Solo permitir método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse([
        'success' => false,
        'message' => 'Método no permitido. Use POST'
    ], 405);
}

// Obtener datos del cuerpo de la petición
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validar que se recibieron los datos
if (!$data) {
    jsonResponse([
        'success' => false,
        'message' => 'No se recibieron datos válidos'
    ], 400);
}

// Extraer campos
$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');

// Validaciones básicas
if (empty($email) || empty($password)) {
    jsonResponse([
        'success' => false,
        'message' => 'Email y contraseña son obligatorios'
    ], 400);
}

if (!isValidEmail($email)) {
    jsonResponse([
        'success' => false,
        'message' => 'El email no es válido'
    ], 400);
}

try {
    $conn = getDBConnection();
    
    // Buscar usuario por email
    $stmt = $conn->prepare("
        SELECT id, nombre, apellido, email, password, activo 
        FROM usuarios 
        WHERE email = ?
    ");
    
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();
    
    // Verificar si el usuario existe
    if (!$usuario) {
        jsonResponse([
            'success' => false,
            'message' => 'Credenciales incorrectas'
        ], 401);
    }
    
    // Verificar si el usuario está activo
    if ($usuario['activo'] != 1) {
        jsonResponse([
            'success' => false,
            'message' => 'Usuario desactivado. Contacte al administrador'
        ], 403);
    }
    
    // Verificar la contraseña
    if (!password_verify($password, $usuario['password'])) {
        jsonResponse([
            'success' => false,
            'message' => 'Credenciales incorrectas'
        ], 401);
    }
    
    // Actualizar última conexión
    $updateStmt = $conn->prepare("
        UPDATE usuarios 
        SET ultima_conexion = CURRENT_TIMESTAMP 
        WHERE id = ?
    ");
    $updateStmt->execute([$usuario['id']]);
    
    // Login exitoso
    jsonResponse([
        'success' => true,
        'message' => 'Inicio de sesión exitoso',
        'data' => [
            'id' => $usuario['id'],
            'nombre' => $usuario['nombre'],
            'apellido' => $usuario['apellido'],
            'email' => $usuario['email'],
            'nombre_completo' => $usuario['nombre'] . ' ' . $usuario['apellido']
        ]
    ], 200);

} catch(PDOException $e){
   jsonResponse([
        'success' => false,
        'message' => 'Error al procesar el inicio de sesión',
        'error' => $e->getMessage()
    ], 500);
}
?>