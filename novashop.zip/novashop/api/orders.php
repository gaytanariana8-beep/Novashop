<?php
// orders.php - Obtener pedidos del usuario
require_once 'config.php';

// Verificar método de solicitud
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse([
        'success' => false,
        'message' => 'Método no permitido'
    ], 405);
}

// Verificar que se haya proporcionado el user_id
if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
    jsonResponse([
        'success' => false,
        'message' => 'ID de usuario requerido'
    ], 400);
}

$userId = intval($_GET['user_id']);

try {
    $conn = getDBConnection();
    
    // Consulta SQL para obtener los pedidos del usuario
    $sql = "SELECT 
                o.id,
                DATE_FORMAT(o.order_date, '%d %b %Y') as date,
                o.status,
                o.total,
                COUNT(oi.id) as items_count,
                (SELECT p.images_url 
                 FROM order_items oi2 
                 JOIN products p ON oi2.product_id = p.id 
                 WHERE oi2.order_id = o.id 
                 LIMIT 1) as image_url
            FROM orders o
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.user_id = :user_id
            GROUP BY o.id, o.order_date, o.status, o.total
            ORDER BY o.order_date DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->execute();
    
    $orders = [];
    while ($row = $stmt->fetch()) {
        $orders[] = [
            'id' => (int)$row['id'],
            'date' => $row['date'],
            'status' => $row['status'],
            'total' => (float)$row['total'],
            'items_count' => (int)$row['items_count'],
            'image_url' => $row['image_url'] ?? ''
        ];
    }
    
    jsonResponse([
        'success' => true,
        'message' => 'Pedidos obtenidos correctamente',
        'data' => [
            'orders' => $orders,
            'count' => count($orders)
        ]
    ]);
    
} catch (PDOException $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Error al obtener pedidos',
        'error' => $e->getMessage()
    ], 500);
}
?>