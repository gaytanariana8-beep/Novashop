<?php
// products.php - API para obtener productos

require_once 'config.php';

// Obtener parámetros
$type = $_GET['type'] ?? 'all'; // all, featured, offers, category
$categoryId = $_GET['category_id'] ?? null;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;

try {
    $conn = getDBConnection();
    
    // Construir query según el tipo
    $query = "SELECT 
        p.id,
        p.nombre AS name,
        p.descripcion AS description,
        p.precio AS price,
        p.precio_anterior AS original_price,
        p.categoria_id,
        p.imagen_url AS imagen_url,  -- ✅ CORREGIDO: ahora usa snake_case
        p.stock,
        p.marca AS brand,
        p.rating,
        p.total_reviews AS totalReviews,
        p.destacado AS featured,
        p.oferta AS offer,
        c.nombre AS category_name
    FROM productos p
    INNER JOIN categorias c ON p.categoria_id = c.id
    WHERE p.activo = 1";
    
    // Filtros adicionales según el tipo
    switch ($type) {
        case 'featured':
            $query .= " AND p.destacado = 1";
            break;
        case 'offers':
            $query .= " AND p.oferta = 1";
            break;
        case 'category':
            if ($categoryId) {
                $query .= " AND p.categoria_id = :category_id";
            }
            break;
    }
    
    $query .= " ORDER BY p.id DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $conn->prepare($query);
    
    // Bind parámetros
    if ($type === 'category' && $categoryId) {
        $stmt->bindValue(':category_id', $categoryId, PDO::PARAM_INT);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $products = $stmt->fetchAll();
    
    // Contar total de productos
    $countQuery = "SELECT COUNT(*) as total FROM productos p WHERE p.activo = 1";
    if ($type === 'featured') {
        $countQuery .= " AND p.destacado = 1";
    } elseif ($type === 'offers') {
        $countQuery .= " AND p.oferta = 1";
    } elseif ($type === 'category' && $categoryId) {
        $countQuery .= " AND p.categoria_id = " . (int)$categoryId;
    }
    
    $totalStmt = $conn->query($countQuery);
    $total = $totalStmt->fetch()['total'];
    
    jsonResponse([
        'success' => true,
        'message' => 'Productos obtenidos exitosamente',
        'data' => [
            'products' => $products,
            'total' => (int)$total,
            'limit' => $limit,
            'offset' => $offset
        ]
    ], 200);
    
} catch(PDOException $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Error al obtener productos',
        'error' => $e->getMessage()
    ], 500);
}
?>