<?php
// categories.php - API para obtener categorías

require_once 'config.php';

try {
    $conn = getDBConnection();
    
    // Obtener todas las categorías activas con el conteo de productos
    $query = "SELECT 
        c.id,
        c.nombre AS name,
        c.descripcion AS description,
        c.icono AS icon,
        c.imagen_url AS imageUrl,
        COUNT(p.id) AS product_count
    FROM categorias c
    LEFT JOIN productos p ON c.id = p.categoria_id AND p.activo = 1
    WHERE c.activo = 1
    GROUP BY c.id, c.nombre, c.descripcion, c.icono, c.imagen_url
    ORDER BY c.orden ASC, c.nombre ASC";
    
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'message' => 'Categorías obtenidas exitosamente',
        'data' => [
            'categories' => $categories,
            'total' => count($categories)
        ]
    ], 200);
    
} catch(PDOException $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Error al obtener categorías',
        'error' => $e->getMessage()
    ], 500);
}
?>