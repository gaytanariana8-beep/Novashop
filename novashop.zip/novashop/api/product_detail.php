<?php
// product_detail.php - API para obtener detalle de un producto

require_once 'config.php';

// Validar que se envió el ID
if (!isset($_GET['id'])) {
    jsonResponse([
        'success' => false,
        'message' => 'ID de producto no proporcionado'
    ], 400);
}

$productId = (int)$_GET['id'];

try {
    $conn = getDBConnection();
    
    // Obtener información del producto
    $query = "SELECT 
        p.id,
        p.nombre AS name,
        p.descripcion AS description,
        p.precio AS price,
        p.precio_anterior AS original_price,
        p.categoria_id,
        p.imagen_url AS imageUrl,
        p.imagenes_adicionales AS additionalImages,
        p.stock,
        p.sku,
        p.marca AS brand,
        p.modelo AS model,
        p.peso AS weight,
        p.dimensiones AS dimensions,
        p.color,
        p.talla AS size,
        p.rating,
        p.total_reviews AS totalReviews,
        p.destacado AS featured,
        p.oferta AS offer,
        c.nombre AS category_name,
        c.id AS category_id
    FROM productos p
    INNER JOIN categorias c ON p.categoria_id = c.id
    WHERE p.id = :id AND p.activo = 1";
    
    $stmt = $conn->prepare($query);
    $stmt->bindValue(':id', $productId, PDO::PARAM_INT);
    $stmt->execute();
    $product = $stmt->fetch();
    
    if (!$product) {
        jsonResponse([
            'success' => false,
            'message' => 'Producto no encontrado'
        ], 404);
    }
    
    // Obtener reviews del producto
    $reviewsQuery = "SELECT 
        r.id,
        r.rating,
        r.titulo AS title,
        r.comentario AS comment,
        r.fecha_creacion AS date,
        r.verificado AS verified,
        CONCAT(u.nombre, ' ', u.apellido) AS user_name
    FROM reviews r
    INNER JOIN usuarios u ON r.usuario_id = u.id
    WHERE r.producto_id = :id
    ORDER BY r.fecha_creacion DESC
    LIMIT 10";
    
    $reviewsStmt = $conn->prepare($reviewsQuery);
    $reviewsStmt->bindValue(':id', $productId, PDO::PARAM_INT);
    $reviewsStmt->execute();
    $reviews = $reviewsStmt->fetchAll();
    
    // Obtener productos relacionados (misma categoría)
    $relatedQuery = "SELECT 
        p.id,
        p.nombre AS name,
        p.precio AS price,
        p.imagen_url AS imageUrl,
        p.rating
    FROM productos p
    WHERE p.categoria_id = :category_id 
    AND p.id != :id 
    AND p.activo = 1
    ORDER BY RAND()
    LIMIT 6";
    
    $relatedStmt = $conn->prepare($relatedQuery);
    $relatedStmt->bindValue(':category_id', $product['categoria_id'], PDO::PARAM_INT);
    $relatedStmt->bindValue(':id', $productId, PDO::PARAM_INT);
    $relatedStmt->execute();
    $relatedProducts = $relatedStmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'message' => 'Producto obtenido exitosamente',
        'data' => [
            'product' => $product,
            'reviews' => $reviews,
            'related_products' => $relatedProducts
        ]
    ], 200);
    
} catch(PDOException $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Error al obtener el producto',
        'error' => $e->getMessage()
    ], 500);
}
?>