<?php
// register.php - API para registrar nuevos usuarios

require_once 'config.php';

// Solo permitir método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse([
        'success' => false,
        'message' => 'Método no permitido. Use POST'
    ], 405);
}

// Obtener datos del cuerpo de la petición
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validar que se recibieron los datos
if (!$data) {
    jsonResponse([
        'success' => false,
        'message' => 'No se recibieron datos válidos'
    ], 400);
}

// Extraer y validar campos
$nombre = trim($data['nombre'] ?? '');
$apellido = trim($data['apellido'] ?? '');
$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');

// Validaciones
$errors = [];

if (empty($nombre)) {
    $errors[] = 'El nombre es obligatorio';
}

if (empty($apellido)) {
    $errors[] = 'El apellido es obligatorio';
}

if (empty($email)) {
    $errors[] = 'El email es obligatorio';
} elseif (!isValidEmail($email)) {
    $errors[] = 'El email no es válido';
}

if (empty($password)) {
    $errors[] = 'La contraseña es obligatoria';
} elseif (strlen($password) < 6) {
    $errors[] = 'La contraseña debe tener al menos 6 caracteres';
}

// Si hay errores, devolverlos
if (!empty($errors)) {
    jsonResponse([
        'success' => false,
        'message' => 'Errores de validación',
        'errors' => $errors
    ], 400);
}

try {
    $conn = getDBConnection();
    
    // Verificar si el email ya existe
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        jsonResponse([
            'success' => false,
            'message' => 'Este correo electrónico ya está registrado'
        ], 409);
    }
    
    // Hashear la contraseña
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Insertar el nuevo usuario
    $stmt = $conn->prepare("
        INSERT INTO usuarios (nombre, apellido, email, password) 
        VALUES (?, ?, ?, ?)
    ");
    
    $stmt->execute([$nombre, $apellido, $email, $hashedPassword]);
    
    // Obtener el ID del usuario creado
    $userId = $conn->lastInsertId();
    
    jsonResponse([
        'success' => true,
        'message' => 'Usuario registrado exitosamente',
        'data' => [
            'id' => $userId,
            'nombre' => $nombre,
            'apellido' => $apellido,
            'email' => $email
        ]
    ], 201);
    
} catch(PDOException $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Error al registrar el usuario',
        'error' => $e->getMessage()
    ], 500);
}
?>