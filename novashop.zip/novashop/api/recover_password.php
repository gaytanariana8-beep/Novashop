<?php
// recover_password.php - Recuperación de contraseña
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

// Log para debugging
file_put_contents('recover_log.txt', date('Y-m-d H:i:s') . " - Inicio de recuperación\n", FILE_APPEND);

// Obtener datos de la solicitud
$input = file_get_contents('php://input');
file_put_contents('recover_log.txt', "Input recibido: $input\n", FILE_APPEND);

$data = json_decode($input, true);

// Validar que se recibieron datos
if (!$data) {
    file_put_contents('recover_log.txt', "Error: No se recibieron datos\n", FILE_APPEND);
    jsonResponse([
        'success' => false,
        'message' => 'No se recibieron datos'
    ], 400);
}

$email = trim($data['email'] ?? '');
file_put_contents('recover_log.txt', "Email recibido: $email\n", FILE_APPEND);

// Validar email
if (empty($email)) {
    jsonResponse([
        'success' => false,
        'message' => 'El correo electrónico es requerido'
    ], 400);
}

if (!isValidEmail($email)) {
    jsonResponse([
        'success' => false,
        'message' => 'Correo electrónico inválido'
    ], 400);
}

try {
    // Obtener conexión
    $conn = getDBConnection();
    file_put_contents('recover_log.txt', "Conexión establecida\n", FILE_APPEND);
    
    // Primero, verificar qué columnas existen en la tabla usuarios
    $columns = $conn->query("SHOW COLUMNS FROM usuarios")->fetchAll(PDO::FETCH_COLUMN);
    file_put_contents('recover_log.txt', "Columnas disponibles: " . implode(", ", $columns) . "\n", FILE_APPEND);
    
    // Determinar si existe 'nombre_completo' o usar 'nombre' y 'apellido'
    $hasNombreCompleto = in_array('nombre_completo', $columns);
    
    // Construir query según las columnas disponibles
    if ($hasNombreCompleto) {
        $selectQuery = "SELECT id, nombre_completo, email FROM usuarios WHERE email = :email";
    } else {
        $selectQuery = "SELECT id, nombre, apellido, email FROM usuarios WHERE email = :email";
    }
    
    file_put_contents('recover_log.txt', "Query: $selectQuery\n", FILE_APPEND);
    
    // Verificar si el usuario existe
    $stmt = $conn->prepare($selectQuery);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->execute();
    
    $user = $stmt->fetch();
    
    if (!$user) {
        file_put_contents('recover_log.txt', "Usuario no encontrado\n", FILE_APPEND);
        jsonResponse([
            'success' => false,
            'message' => 'No existe una cuenta con este correo electrónico'
        ], 404);
    }
    
    $userId = $user['id'];
    
    // Obtener nombre completo según estructura
    if ($hasNombreCompleto) {
        $nombreCompleto = $user['nombre_completo'];
    } else {
        $nombreCompleto = $user['nombre'] . ' ' . $user['apellido'];
    }
    
    file_put_contents('recover_log.txt', "Usuario encontrado: ID=$userId, Nombre=$nombreCompleto\n", FILE_APPEND);
    
    // Generar nueva contraseña temporal (8 caracteres aleatorios)
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $newPassword = '';
    for ($i = 0; $i < 8; $i++) {
        $newPassword .= $characters[rand(0, strlen($characters) - 1)];
    }
    file_put_contents('recover_log.txt', "Contraseña generada: $newPassword\n", FILE_APPEND);
    
    // Hashear la nueva contraseña
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    file_put_contents('recover_log.txt', "Contraseña hasheada\n", FILE_APPEND);
    
    // Actualizar contraseña en la base de datos
    $stmt = $conn->prepare("UPDATE usuarios SET password = :password WHERE id = :id");
    $stmt->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
    $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        file_put_contents('recover_log.txt', "Contraseña actualizada exitosamente\n", FILE_APPEND);
        
        // Respuesta exitosa
        jsonResponse([
            'success' => true,
            'message' => 'Se ha generado una nueva contraseña. Contraseña temporal: ' . $newPassword,
            'data' => [
                'email' => $email,
                'nombre' => $nombreCompleto,
                'temp_password' => $newPassword
            ]
        ], 200);
    } else {
        file_put_contents('recover_log.txt', "Error al ejecutar UPDATE\n", FILE_APPEND);
        jsonResponse([
            'success' => false,
            'message' => 'Error al actualizar la contraseña'
        ], 500);
    }
    
} catch (PDOException $e) {
    file_put_contents('recover_log.txt', "Error PDO: " . $e->getMessage() . "\n", FILE_APPEND);
    file_put_contents('recover_log.txt', "SQL State: " . $e->getCode() . "\n", FILE_APPEND);
    jsonResponse([
        'success' => false,
        'message' => 'Error del servidor',
        'error' => $e->getMessage(),
        'sql_state' => $e->getCode()
    ], 500);
} catch (Exception $e) {
    file_put_contents('recover_log.txt', "Error general: " . $e->getMessage() . "\n", FILE_APPEND);
    jsonResponse([
        'success' => false,
        'message' => 'Error inesperado',
        'error' => $e->getMessage()
    ], 500);
}
?>