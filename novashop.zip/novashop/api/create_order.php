<?php
// create_order.php - Crear nuevo pedido
require_once 'config.php';

// Verificar método de solicitud
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse([
        'success' => false,
        'message' => 'Método no permitido'
    ], 405);
}

// Obtener datos JSON
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validar datos requeridos
if (!isset($data['user_id']) || !isset($data['items']) || !isset($data['total'])) {
    jsonResponse([
        'success' => false,
        'message' => 'Datos incompletos. Se requiere: user_id, items y total'
    ], 400);
}

$userId = intval($data['user_id']);
$items = $data['items'];
$total = floatval($data['total']);
$shippingAddress = $data['shipping_address'] ?? '';
$paymentMethod = $data['payment_method'] ?? 'card';

// Validar que haya items
if (empty($items) || !is_array($items)) {
    jsonResponse([
        'success' => false,
        'message' => 'No se proporcionaron items para el pedido'
    ], 400);
}

try {
    $conn = getDBConnection();
    
    // Iniciar transacción
    $conn->beginTransaction();
    
    // Insertar el pedido
    $sqlOrder = "INSERT INTO orders (user_id, total, status, shipping_address, payment_method, order_date) 
                 VALUES (:user_id, :total, 'in_progress', :shipping_address, :payment_method, NOW())";
    
    $stmtOrder = $conn->prepare($sqlOrder);
    $stmtOrder->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmtOrder->bindParam(':total', $total);
    $stmtOrder->bindParam(':shipping_address', $shippingAddress);
    $stmtOrder->bindParam(':payment_method', $paymentMethod);
    $stmtOrder->execute();
    
    $orderId = $conn->lastInsertId();
    
    // Insertar los items del pedido
    $sqlItem = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                VALUES (:order_id, :product_id, :quantity, :price)";
    $stmtItem = $conn->prepare($sqlItem);
    
    foreach ($items as $item) {
        if (!isset($item['product_id']) || !isset($item['quantity']) || !isset($item['price'])) {
            throw new Exception('Datos de item incompletos');
        }
        
        $productId = intval($item['product_id']);
        $quantity = intval($item['quantity']);
        $price = floatval($item['price']);
        
        $stmtItem->bindParam(':order_id', $orderId, PDO::PARAM_INT);
        $stmtItem->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmtItem->bindParam(':quantity', $quantity, PDO::PARAM_INT);
        $stmtItem->bindParam(':price', $price);
        $stmtItem->execute();
        
        // Opcional: Actualizar stock del producto
        // $sqlStock = "UPDATE products SET stock = stock - :quantity WHERE id = :product_id";
        // $stmtStock = $conn->prepare($sqlStock);
        // $stmtStock->bindParam(':quantity', $quantity, PDO::PARAM_INT);
        // $stmtStock->bindParam(':product_id', $productId, PDO::PARAM_INT);
        // $stmtStock->execute();
    }
    
    // Confirmar transacción
    $conn->commit();
    
    jsonResponse([
        'success' => true,
        'message' => 'Pedido creado exitosamente',
        'data' => [
            'order_id' => (int)$orderId,
            'total' => $total,
            'status' => 'in_progress',
            'items_count' => count($items)
        ]
    ], 201);
    
} catch (Exception $e) {
    // Revertir transacción en caso de error
    if ($conn->inTransaction()) {
        $conn->rollback();
    }
    
    jsonResponse([
        'success' => false,
        'message' => 'Error al crear pedido',
        'error' => $e->getMessage()
    ], 500);
}
?>