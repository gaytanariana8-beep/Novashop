package com.example.novashop


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class ManageCustomersActivity : AppCompatActivity() {

    private lateinit var rvCustomers: RecyclerView
    private var customers = mutableListOf<Customer>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_customers)

        initializeViews()
        loadCustomers()
    }

    private fun initializeViews() {
        rvCustomers = findViewById(R.id.rvCustomers)
    }

    private fun loadCustomers() {
        customers = mutableListOf(
            Customer(1, "Juan Pérez", "juan.perez@email.com", "+52 123 456 7890", 5, 2450.00),
            Customer(2, "María García", "maria.garcia@email.com", "+52 234 567 8901", 3, 1299.50),
            Customer(3, "Carlos López", "carlos.lopez@email.com", "+52 345 678 9012", 8, 4567.89),
            Customer(4, "Ana Martínez", "ana.martinez@email.com", "+52 456 789 0123", 2, 599.99),
            Customer(5, "Luis Rodríguez", "luis.rodriguez@email.com", "+52 567 890 1234", 4, 1890.45)
        )

        rvCustomers.layoutManager = LinearLayoutManager(this)
        rvCustomers.adapter = CustomerAdapter(customers) { customer ->
            showCustomerDetails(customer)
        }
    }

    private fun showCustomerDetails(customer: Customer) {
        val message = """
            Nombre: ${customer.name}
            Email: ${customer.email}
            Teléfono: ${customer.phone}
            Total de Pedidos: ${customer.totalOrders}
            Gasto Total: $${String.format("%.2f", customer.totalSpent)}
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Información del Cliente")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}

data class Customer(
    val id: Int,
    val name: String,
    val email: String,
    val phone: String,
    val totalOrders: Int,
    val totalSpent: Double
)

class CustomerAdapter(
    private val customers: List<Customer>,
    private val onCustomerClick: (Customer) -> Unit
) : RecyclerView.Adapter<CustomerAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtCustomerName: AppCompatTextView =
            itemView.findViewById(R.id.txtCustomerName)
        val txtCustomerEmail: AppCompatTextView =
            itemView.findViewById(R.id.txtCustomerEmail)
        val txtTotalOrders: AppCompatTextView =
            itemView.findViewById(R.id.txtTotalOrders)
        val txtTotalSpent: AppCompatTextView =
            itemView.findViewById(R.id.txtTotalSpent)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_customer, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val customer = customers[position]

        holder.txtCustomerName.text = customer.name
        holder.txtCustomerEmail.text = customer.email
        holder.txtTotalOrders.text = "${customer.totalOrders} pedidos"
        holder.txtTotalSpent.text = "$${String.format("%.2f", customer.totalSpent)}"

        holder.itemView.setOnClickListener {
            onCustomerClick(customer)
        }
    }

    override fun getItemCount(): Int = customers.size
}