package com.example.novashop


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class CartAdapter(
    private val cartItems: MutableList<CartItem>,
    private val onQuantityChanged: () -> Unit,
    private val onItemRemoved: (CartItem) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    inner class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardCartItem: CardView = itemView.findViewById(R.id.cardCartItem)
        val imgCartProduct: ImageView = itemView.findViewById(R.id.imgCartProduct)
        val txtCartProductName: AppCompatTextView = itemView.findViewById(R.id.txtCartProductName)
        val txtCartPrice: AppCompatTextView = itemView.findViewById(R.id.txtCartPrice)
        val txtQuantity: AppCompatTextView = itemView.findViewById(R.id.txtQuantity)
        val btnDecrease: AppCompatButton = itemView.findViewById(R.id.btnDecrease)
        val btnIncrease: AppCompatButton = itemView.findViewById(R.id.btnIncrease)
        val btnRemove: ImageView = itemView.findViewById(R.id.btnRemove)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val item = cartItems[position]

        holder.txtCartProductName.text = item.name
        holder.txtCartPrice.text = "$${String.format("%.2f", item.price * item.quantity)}"
        holder.txtQuantity.text = item.quantity.toString()

        holder.btnDecrease.setOnClickListener {
            if (item.quantity > 1) {
                item.quantity--
                notifyItemChanged(position)
                onQuantityChanged()
            }
        }

        holder.btnIncrease.setOnClickListener {
            if (item.quantity < 99) {
                item.quantity++
                notifyItemChanged(position)
                onQuantityChanged()
            }
        }

        holder.btnRemove.setOnClickListener {
            onItemRemoved(item)
        }
    }

    override fun getItemCount(): Int = cartItems.size
}