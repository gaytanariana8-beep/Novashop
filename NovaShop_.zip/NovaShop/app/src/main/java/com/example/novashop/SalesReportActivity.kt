package com.example.novashop


import android.os.Bundle
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import com.example.ejemplo.R

class SalesReportActivity : AppCompatActivity() {

    private lateinit var rgTimePeriod: RadioGroup
    private lateinit var txtTotalRevenue: AppCompatTextView
    private lateinit var txtTotalOrders: AppCompatTextView
    private lateinit var txtAvgOrderValue: AppCompatTextView
    private lateinit var txtNewCustomers: AppCompatTextView
    private lateinit var txtTopProduct: AppCompatTextView
    private lateinit var txtTopCategory: AppCompatTextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sales_report)

        initializeViews()
        loadReport("monthly")
        setupListeners()
    }

    private fun initializeViews() {
        rgTimePeriod = findViewById(R.id.rgTimePeriod)
        txtTotalRevenue = findViewById(R.id.txtTotalRevenue)
        txtTotalOrders = findViewById(R.id.txtTotalOrders)
        txtAvgOrderValue = findViewById(R.id.txtAvgOrderValue)
        txtNewCustomers = findViewById(R.id.txtNewCustomers)
        txtTopProduct = findViewById(R.id.txtTopProduct)
        txtTopCategory = findViewById(R.id.txtTopCategory)
    }

    private fun setupListeners() {
        rgTimePeriod.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbDaily -> loadReport("daily")
                R.id.rbWeekly -> loadReport("weekly")
                R.id.rbMonthly -> loadReport("monthly")
                R.id.rbYearly -> loadReport("yearly")
            }
        }
    }

    private fun loadReport(period: String) {
        // Datos de ejemplo según el período
        when (period) {
            "daily" -> {
                txtTotalRevenue.text = "$2,450.00"
                txtTotalOrders.text = "18"
                txtAvgOrderValue.text = "$136.11"
                txtNewCustomers.text = "3"
                txtTopProduct.text = "Smartphone XZ Pro"
                txtTopCategory.text = "Electrónicos"
            }
            "weekly" -> {
                txtTotalRevenue.text = "$15,890.00"
                txtTotalOrders.text = "97"
                txtAvgOrderValue.text = "$163.81"
                txtNewCustomers.text = "24"
                txtTopProduct.text = "Laptop Ultra 15"
                txtTopCategory.text = "Electrónicos"
            }
            "monthly" -> {
                txtTotalRevenue.text = "$45,890.00"
                txtTotalOrders.text = "248"
                txtAvgOrderValue.text = "$185.04"
                txtNewCustomers.text = "87"
                txtTopProduct.text = "Smartwatch Fit"
                txtTopCategory.text = "Electrónicos"
            }
            "yearly" -> {
                txtTotalRevenue.text = "$489,670.00"
                txtTotalOrders.text = "2,834"
                txtAvgOrderValue.text = "$172.82"
                txtNewCustomers.text = "945"
                txtTopProduct.text = "Auriculares Wireless"
                txtTopCategory.text = "Electrónicos"
            }
        }
    }
}