package com.example.novashop


import android.os.Bundle
import android.widget.CheckBox
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import com.example.ejemplo.R
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class FilterActivity : AppCompatActivity() {

    private lateinit var seekBarPrice: SeekBar
    private lateinit var txtPriceRange: AppCompatTextView
    private lateinit var chipGroupCategories: ChipGroup
    private lateinit var cbInStock: CheckBox
    private lateinit var cbFreeShipping: CheckBox
    private lateinit var cbHighRating: CheckBox
    private lateinit var chipGroupBrands: ChipGroup
    private lateinit var btnClearFilters: AppCompatButton
    private lateinit var btnApplyFilters: AppCompatButton

    private var minPrice = 0
    private var maxPrice = 2000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter)

        initializeViews()
        setupListeners()
        setupCategories()
        setupBrands()
    }

    private fun initializeViews() {
        seekBarPrice = findViewById(R.id.seekBarPrice)
        txtPriceRange = findViewById(R.id.txtPriceRange)
        chipGroupCategories = findViewById(R.id.chipGroupCategories)
        cbInStock = findViewById(R.id.cbInStock)
        cbFreeShipping = findViewById(R.id.cbFreeShipping)
        cbHighRating = findViewById(R.id.cbHighRating)
        chipGroupBrands = findViewById(R.id.chipGroupBrands)
        btnClearFilters = findViewById(R.id.btnClearFilters)
        btnApplyFilters = findViewById(R.id.btnApplyFilters)
    }

    private fun setupListeners() {
        seekBarPrice.max = 2000
        seekBarPrice.progress = 2000
        txtPriceRange.text = "$0 - $2000"

        seekBarPrice.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                maxPrice = progress
                txtPriceRange.text = "$$minPrice - $$maxPrice"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnClearFilters.setOnClickListener {
            clearAllFilters()
        }

        btnApplyFilters.setOnClickListener {
            applyFilters()
        }
    }

    private fun setupCategories() {
        val categories = listOf("Electrónicos", "Ropa", "Hogar", "Deportes", "Libros", "Juguetes")

        categories.forEach { category ->
            val chip = Chip(this)
            chip.text = category
            chip.isCheckable = true
            chipGroupCategories.addView(chip)
        }
    }

    private fun setupBrands() {
        val brands = listOf("Samsung", "Apple", "Sony", "LG", "HP", "Dell", "Nike", "Adidas")

        brands.forEach { brand ->
            val chip = Chip(this)
            chip.text = brand
            chip.isCheckable = true
            chipGroupBrands.addView(chip)
        }
    }

    private fun clearAllFilters() {
        seekBarPrice.progress = 2000
        maxPrice = 2000
        txtPriceRange.text = "$0 - $2000"

        chipGroupCategories.clearCheck()
        chipGroupBrands.clearCheck()

        cbInStock.isChecked = false
        cbFreeShipping.isChecked = false
        cbHighRating.isChecked = false
    }

    private fun applyFilters() {
        val selectedCategories = mutableListOf<String>()
        val selectedBrands = mutableListOf<String>()

        for (i in 0 until chipGroupCategories.childCount) {
            val chip = chipGroupCategories.getChildAt(i) as Chip
            if (chip.isChecked) {
                selectedCategories.add(chip.text.toString())
            }
        }

        for (i in 0 until chipGroupBrands.childCount) {
            val chip = chipGroupBrands.getChildAt(i) as Chip
            if (chip.isChecked) {
                selectedBrands.add(chip.text.toString())
            }
        }

        // Aquí aplicarías los filtros
        // Por ahora solo regresamos los resultados
        val resultIntent = intent
        resultIntent.putExtra("MAX_PRICE", maxPrice)
        resultIntent.putExtra("IN_STOCK", cbInStock.isChecked)
        resultIntent.putExtra("FREE_SHIPPING", cbFreeShipping.isChecked)
        resultIntent.putExtra("HIGH_RATING", cbHighRating.isChecked)
        resultIntent.putStringArrayListExtra("CATEGORIES", ArrayList(selectedCategories))
        resultIntent.putStringArrayListExtra("BRANDS", ArrayList(selectedBrands))

        setResult(RESULT_OK, resultIntent)
        finish()
    }
}