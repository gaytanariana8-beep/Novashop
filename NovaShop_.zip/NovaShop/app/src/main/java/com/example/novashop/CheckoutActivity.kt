package com.example.novashop

import android.content.Intent
import android.os.Bundle
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import androidx.appcompat.widget.AppCompatTextView
import com.example.ejemplo.R

class CheckoutActivity : AppCompatActivity() {

    private lateinit var etAddress: AppCompatEditText
    private lateinit var etCity: AppCompatEditText
    private lateinit var etPostalCode: AppCompatEditText
    private lateinit var etPhone: AppCompatEditText
    private lateinit var rgShipping: RadioGroup
    private lateinit var rgPayment: RadioGroup
    private lateinit var txtOrderSubtotal: AppCompatTextView
    private lateinit var txtOrderShipping: AppCompatTextView
    private lateinit var txtOrderTotal: AppCompatTextView
    private lateinit var btnConfirmOrder: AppCompatButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        initializeViews()
        setupClickListeners()
        calculateTotals()
    }

    private fun initializeViews() {
        etAddress = findViewById(R.id.etAddress)
        etCity = findViewById(R.id.etCity)
        etPostalCode = findViewById(R.id.etPostalCode)
        etPhone = findViewById(R.id.etPhone)
        rgShipping = findViewById(R.id.rgShipping)
        rgPayment = findViewById(R.id.rgPayment)
        txtOrderSubtotal = findViewById(R.id.txtOrderSubtotal)
        txtOrderShipping = findViewById(R.id.txtOrderShipping)
        txtOrderTotal = findViewById(R.id.txtOrderTotal)
        btnConfirmOrder = findViewById(R.id.btnConfirmOrder)
    }

    private fun setupClickListeners() {
        btnConfirmOrder.setOnClickListener {
            if (validateForm()) {
                processOrder()
            }
        }

        rgShipping.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbStandard -> calculateTotals(15.0)
                R.id.rbExpress -> calculateTotals(30.0)
            }
        }
    }

    private fun validateForm(): Boolean {
        if (etAddress.text.toString().trim().isEmpty()) {
            etAddress.error = "Ingrese su dirección"
            return false
        }

        if (etCity.text.toString().trim().isEmpty()) {
            etCity.error = "Ingrese su ciudad"
            return false
        }

        if (etPostalCode.text.toString().trim().isEmpty()) {
            etPostalCode.error = "Ingrese su código postal"
            return false
        }

        if (etPhone.text.toString().trim().isEmpty()) {
            etPhone.error = "Ingrese su teléfono"
            return false
        }

        if (rgShipping.checkedRadioButtonId == -1) {
            Toast.makeText(this, "Seleccione método de envío", Toast.LENGTH_SHORT).show()
            return false
        }

        if (rgPayment.checkedRadioButtonId == -1) {
            Toast.makeText(this, "Seleccione forma de pago", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

    private fun calculateTotals(shippingCost: Double = 15.0) {
        val subtotal = 949.98
        val total = subtotal + shippingCost

        txtOrderSubtotal.text = "$${"%.2f".format(subtotal)}"
        txtOrderShipping.text = "$${"%.2f".format(shippingCost)}"
        txtOrderTotal.text = "$${"%.2f".format(total)}"
    }

    private fun processOrder() {
        val orderNumber = (10000..99999).random()

        val intent = Intent(this, OrderConfirmationActivity::class.java)
        intent.putExtra("ORDER_NUMBER", orderNumber)
        startActivity(intent)
        finish()
    }
}