package com.example.novashop

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.ejemplo.R

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // TODO: Implementar productos después de crear los layouts necesarios
        // Por ahora solo muestra el layout estático
    }
}

// Modelos de datos (mantener estas clases aquí temporalmente)
data class Product(
    val id: Int,
    val name: String,
    val price: Double,
    val imageUrl: String,
    val rating: Float
)

data class Category(
    val id: Int,
    val name: String,
    val icon: String
)