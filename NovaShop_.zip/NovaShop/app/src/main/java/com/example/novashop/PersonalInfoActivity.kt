package com.example.novashop


import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import com.example.ejemplo.R

class PersonalInfoActivity : AppCompatActivity() {

    private lateinit var etFirstName: AppCompatEditText
    private lateinit var etLastName: AppCompatEditText
    private lateinit var etEmail: AppCompatEditText
    private lateinit var etPhone: AppCompatEditText
    private lateinit var etAddress: AppCompatEditText
    private lateinit var etCity: AppCompatEditText
    private lateinit var etCountry: AppCompatEditText
    private lateinit var btnSaveInfo: AppCompatButton
    private lateinit var btnCancel: AppCompatButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_personal_info)

        initializeViews()
        loadUserData()
        setupClickListeners()
    }

    private fun initializeViews() {
        etFirstName = findViewById(R.id.etFirstName)
        etLastName = findViewById(R.id.etLastName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        etAddress = findViewById(R.id.etAddress)
        etCity = findViewById(R.id.etCity)
        etCountry = findViewById(R.id.etCountry)
        btnSaveInfo = findViewById(R.id.btnSaveInfo)
        btnCancel = findViewById(R.id.btnCancel)
    }

    private fun loadUserData() {
        // Cargar datos del usuario (ejemplo)
        etFirstName.setText("Juan")
        etLastName.setText("Pérez")
        etEmail.setText("juan.perez@email.com")
        etPhone.setText("+52 123 456 7890")
        etAddress.setText("Calle Principal 123")
        etCity.setText("Ciudad de México")
        etCountry.setText("México")
    }

    private fun setupClickListeners() {
        btnSaveInfo.setOnClickListener {
            if (validateForm()) {
                saveUserInfo()
            }
        }

        btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun validateForm(): Boolean {
        if (etFirstName.text.toString().trim().isEmpty()) {
            etFirstName.error = "Ingrese su nombre"
            return false
        }

        if (etLastName.text.toString().trim().isEmpty()) {
            etLastName.error = "Ingrese su apellido"
            return false
        }

        if (etEmail.text.toString().trim().isEmpty()) {
            etEmail.error = "Ingrese su correo"
            return false
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(etEmail.text.toString()).matches()) {
            etEmail.error = "Correo inválido"
            return false
        }

        if (etPhone.text.toString().trim().isEmpty()) {
            etPhone.error = "Ingrese su teléfono"
            return false
        }

        return true
    }

    private fun saveUserInfo() {
        // Aquí guardarías la información del usuario
        Toast.makeText(this, "Información actualizada correctamente", Toast.LENGTH_SHORT).show()
        finish()
    }
}