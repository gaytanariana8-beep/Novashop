package com.example.novashop


import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class CategoryProductsActivity : AppCompatActivity() {

    private lateinit var imgBack: ImageView
    private lateinit var txtCategoryTitle: AppCompatTextView
    private lateinit var rvCategoryProducts: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_products)

        val categoryId = intent.getIntExtra("CATEGORY_ID", 0)

        initializeViews()
        loadCategoryProducts(categoryId)
        setupClickListeners()
    }

    private fun initializeViews() {
        imgBack = findViewById(R.id.imgBack)
        txtCategoryTitle = findViewById(R.id.txtCategoryTitle)
        rvCategoryProducts = findViewById(R.id.rvCategoryProducts)
    }

    private fun loadCategoryProducts(categoryId: Int) {
        // Obtener nombre de categoría
        val categoryName = when (categoryId) {
            1 -> "Electrónicos"
            2 -> "Ropa"
            3 -> "Hogar"
            4 -> "Deportes"
            5 -> "Libros"
            else -> "Productos"
        }

        txtCategoryTitle.text = categoryName

        // Cargar productos de la categoría
        val products = getProductsByCategory(categoryId)

        rvCategoryProducts.layoutManager = GridLayoutManager(this, 2)
        rvCategoryProducts.adapter = ProductAdapter(products, true) { product ->
            val intent = Intent(this, ProductDetailActivity::class.java)
            intent.putExtra("PRODUCT_ID", product.id)
            startActivity(intent)
        }
    }

    private fun setupClickListeners() {
        imgBack.setOnClickListener {
            finish()
        }
    }

    private fun getProductsByCategory(categoryId: Int): List<Product> {

        return when (categoryId) {
            1 -> listOf(
                Product(1, "Smartphone XZ Pro", 799.99, "url", 4.5f),
                Product(2, "Laptop Ultra 15", 1299.99, "url", 4.7f),
                Product(3, "Tablet Pro 10", 399.99, "url", 4.4f),
                Product(4, "Smartwatch Fit", 249.99, "url", 4.6f)
            )
            2 -> listOf(
                Product(10, "Camiseta Deportiva", 29.99, "url", 4.2f),
                Product(11, "Pantalón Casual", 49.99, "url", 4.3f),
                Product(12, "Zapatos Running", 89.99, "url", 4.8f)
            )
            else -> listOf(
                Product(20, "Producto Genérico 1", 99.99, "url", 4.0f),
                Product(21, "Producto Genérico 2", 149.99, "url", 4.1f)
            )
        }
    }
}