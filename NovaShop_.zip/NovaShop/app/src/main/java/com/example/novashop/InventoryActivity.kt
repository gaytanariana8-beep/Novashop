package com.example.novashop


import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class InventoryActivity : AppCompatActivity() {

    private lateinit var rvInventory: RecyclerView
    private var inventoryItems = mutableListOf<InventoryItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)

        initializeViews()
        loadInventory()
    }

    private fun initializeViews() {
        rvInventory = findViewById(R.id.rvInventory)
    }

    private fun loadInventory() {
        inventoryItems = mutableListOf(
            InventoryItem(1, "Smartphone XZ Pro", 45, 10, "En Stock"),
            InventoryItem(2, "Laptop Ultra 15", 23, 5, "En Stock"),
            InventoryItem(3, "Auriculares Wireless", 8, 10, "Stock Bajo"),
            InventoryItem(4, "Smartwatch Fit", 67, 15, "En Stock"),
            InventoryItem(5, "Tablet Pro 10", 3, 10, "Stock Crítico"),
            InventoryItem(6, "Cámara Digital HD", 34, 8, "En Stock"),
            InventoryItem(7, "Bocina Bluetooth", 5, 10, "Stock Bajo"),
            InventoryItem(8, "Teclado Mecánico", 89, 20, "En Stock")
        )

        rvInventory.layoutManager = LinearLayoutManager(this)
        rvInventory.adapter = InventoryAdapter(inventoryItems)
    }
}

data class InventoryItem(
    val id: Int,
    val productName: String,
    val stock: Int,
    val minStock: Int,
    val status: String
)

class InventoryAdapter(
    private val items: List<InventoryItem>
) : RecyclerView.Adapter<InventoryAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtProductName: AppCompatTextView =
            itemView.findViewById(R.id.txtProductName)
        val txtStock: AppCompatTextView =
            itemView.findViewById(R.id.txtStock)
        val txtMinStock: AppCompatTextView =
            itemView.findViewById(R.id.txtMinStock)
        val txtStatus: AppCompatTextView =
            itemView.findViewById(R.id.txtStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_inventory, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        holder.txtProductName.text = item.productName
        holder.txtStock.text = "Stock: ${item.stock}"
        holder.txtMinStock.text = "Mínimo: ${item.minStock}"
        holder.txtStatus.text = item.status

        // Color según el estado
        val statusColor = when (item.status) {
            "En Stock" -> Color.parseColor("#388E3C")
            "Stock Bajo" -> Color.parseColor("#F57C00")
            "Stock Crítico" -> Color.parseColor("#D32F2F")
            else -> Color.parseColor("#5A5A5A")
        }

        holder.txtStatus.setTextColor(statusColor)
    }

    override fun getItemCount(): Int = items.size
}