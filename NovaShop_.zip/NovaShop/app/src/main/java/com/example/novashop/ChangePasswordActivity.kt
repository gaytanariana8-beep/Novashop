package com.example.novashop


import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import com.example.ejemplo.R

class ChangePasswordActivity : AppCompatActivity() {

    private lateinit var etCurrentPassword: AppCompatEditText
    private lateinit var etNewPassword: AppCompatEditText
    private lateinit var etConfirmNewPassword: AppCompatEditText
    private lateinit var btnChangePassword: AppCompatButton
    private lateinit var btnCancelChange: AppCompatButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        initializeViews()
        setupClickListeners()
    }

    private fun initializeViews() {
        etCurrentPassword = findViewById(R.id.etCurrentPassword)
        etNewPassword = findViewById(R.id.etNewPassword)
        etConfirmNewPassword = findViewById(R.id.etConfirmNewPassword)
        btnChangePassword = findViewById(R.id.btnChangePassword)
        btnCancelChange = findViewById(R.id.btnCancelChange)
    }

    private fun setupClickListeners() {
        btnChangePassword.setOnClickListener {
            if (validatePasswords()) {
                changePassword()
            }
        }

        btnCancelChange.setOnClickListener {
            finish()
        }
    }

    private fun validatePasswords(): Boolean {
        val currentPassword = etCurrentPassword.text.toString().trim()
        val newPassword = etNewPassword.text.toString().trim()
        val confirmPassword = etConfirmNewPassword.text.toString().trim()

        if (currentPassword.isEmpty()) {
            etCurrentPassword.error = "Ingrese su contraseña actual"
            return false
        }

        if (newPassword.isEmpty()) {
            etNewPassword.error = "Ingrese su nueva contraseña"
            return false
        }

        if (newPassword.length < 6) {
            etNewPassword.error = "La contraseña debe tener al menos 6 caracteres"
            return false
        }

        if (confirmPassword.isEmpty()) {
            etConfirmNewPassword.error = "Confirme su nueva contraseña"
            return false
        }

        if (newPassword != confirmPassword) {
            etConfirmNewPassword.error = "Las contraseñas no coinciden"
            return false
        }

        if (currentPassword == newPassword) {
            etNewPassword.error = "La nueva contraseña debe ser diferente a la actual"
            return false
        }

        return true
    }

    private fun changePassword() {
        // Aquí cambiarías la contraseña
        Toast.makeText(this, "Contraseña actualizada correctamente", Toast.LENGTH_SHORT).show()
        finish()
    }
}