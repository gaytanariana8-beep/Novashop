package com.example.novashop

import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import androidx.appcompat.widget.AppCompatTextView
import androidx.lifecycle.lifecycleScope
import com.example.ejemplo.R
import com.example.novashop.network.ApiService
import kotlinx.coroutines.launch

class SignUpActivity : AppCompatActivity() {

    private lateinit var etFirstName: AppCompatEditText
    private lateinit var etLastName: AppCompatEditText
    private lateinit var etEmail: AppCompatEditText
    private lateinit var etPassword: AppCompatEditText
    private lateinit var etConfirmPassword: AppCompatEditText
    private lateinit var btnRegister: AppCompatButton
    private lateinit var txtLogin: AppCompatTextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        initializeViews()
        setupClickListeners()
    }

    private fun initializeViews() {
        etFirstName = findViewById(R.id.etFirstName)
        etLastName = findViewById(R.id.etLastName)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)
        txtLogin = findViewById(R.id.txtLogin)
    }

    private fun setupClickListeners() {
        btnRegister.setOnClickListener {
            validateAndRegister()
        }

        txtLogin.setOnClickListener {
            finish()
        }
    }

    private fun validateAndRegister() {
        val firstName = etFirstName.text.toString().trim()
        val lastName = etLastName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()
        val confirmPassword = etConfirmPassword.text.toString().trim()

        // Validaciones
        if (firstName.isEmpty()) {
            etFirstName.error = "Ingrese su nombre"
            etFirstName.requestFocus()
            return
        }

        if (lastName.isEmpty()) {
            etLastName.error = "Ingrese su apellido"
            etLastName.requestFocus()
            return
        }

        if (email.isEmpty()) {
            etEmail.error = "Ingrese su correo electrónico"
            etEmail.requestFocus()
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.error = "Correo electrónico inválido"
            etEmail.requestFocus()
            return
        }

        if (password.isEmpty()) {
            etPassword.error = "Ingrese su contraseña"
            etPassword.requestFocus()
            return
        }

        if (password.length < 6) {
            etPassword.error = "La contraseña debe tener al menos 6 caracteres"
            etPassword.requestFocus()
            return
        }

        if (confirmPassword.isEmpty()) {
            etConfirmPassword.error = "Confirme su contraseña"
            etConfirmPassword.requestFocus()
            return
        }

        if (password != confirmPassword) {
            etConfirmPassword.error = "Las contraseñas no coinciden"
            etConfirmPassword.requestFocus()
            return
        }

        // Registrar usuario
        registerUser(firstName, lastName, email, password)
    }

    private fun registerUser(
        nombre: String,
        apellido: String,
        email: String,
        password: String
    ) {
        btnRegister.isEnabled = false
        btnRegister.text = "Registrando..."

        lifecycleScope.launch {
            val response = ApiService.registerUser(nombre, apellido, email, password)

            runOnUiThread {
                btnRegister.isEnabled = true
                btnRegister.text = "Registrarse"

                if (response.success) {
                    Toast.makeText(
                        this@SignUpActivity,
                        " ${response.message}",
                        Toast.LENGTH_LONG
                    ).show()


                    clearFields()


                    finish()
                } else {

                    val errorMessage = if (response.errors != null && response.errors.isNotEmpty()) {
                        response.errors.joinToString("\n")
                    } else {
                        response.message
                    }

                    Toast.makeText(
                        this@SignUpActivity,
                        errorMessage,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun clearFields() {
        etFirstName.text?.clear()
        etLastName.text?.clear()
        etEmail.text?.clear()
        etPassword.text?.clear()
        etConfirmPassword.text?.clear()
    }
}