package com.example.novashop


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class OrdersAdapter(
    private val orders: List<Order>,
    private val onOrderClick: (Order) -> Unit
) : RecyclerView.Adapter<OrdersAdapter.OrderViewHolder>() {

    inner class OrderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardOrder: CardView = itemView.findViewById(R.id.cardOrder)
        val imgOrderProduct: ImageView = itemView.findViewById(R.id.imgOrderProduct)
        val txtOrderNumber: AppCompatTextView = itemView.findViewById(R.id.txtOrderNumber)
        val txtOrderDate: AppCompatTextView = itemView.findViewById(R.id.txtOrderDate)
        val txtOrderStatus: AppCompatTextView = itemView.findViewById(R.id.txtOrderStatus)
        val txtOrderTotal: AppCompatTextView = itemView.findViewById(R.id.txtOrderTotal)
        val txtOrderItems: AppCompatTextView = itemView.findViewById(R.id.txtOrderItems)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_order, parent, false)
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orders[position]

        holder.txtOrderNumber.text = "Pedido #${order.id}"
        holder.txtOrderDate.text = order.date
        holder.txtOrderTotal.text = "$${String.format("%.2f", order.total)}"
        holder.txtOrderItems.text = "${order.items} ${if (order.items == 1) "artículo" else "artículos"}"

        // Estado del pedido
        when (order.status) {
            OrderStatus.IN_PROGRESS -> {
                holder.txtOrderStatus.text = "En Proceso"
                holder.txtOrderStatus.setTextColor(
                    ContextCompat.getColor(holder.itemView.context, R.color.status_in_progress)
                )
            }
            OrderStatus.DELIVERED -> {
                holder.txtOrderStatus.text = "Entregado"
                holder.txtOrderStatus.setTextColor(
                    ContextCompat.getColor(holder.itemView.context, R.color.status_delivered)
                )
            }
            OrderStatus.CANCELLED -> {
                holder.txtOrderStatus.text = "Cancelado"
                holder.txtOrderStatus.setTextColor(
                    ContextCompat.getColor(holder.itemView.context, R.color.status_cancelled)
                )
            }
        }

        holder.cardOrder.setOnClickListener {
            onOrderClick(order)
        }
    }

    override fun getItemCount(): Int = orders.size
}