package com.example.novashop

import android.app.Application
import android.content.Context

class NovaShopApplication : Application() {

    companion object {
        private lateinit var instance: NovaShopApplication

        fun getAppContext(): Context {
            return instance.applicationContext
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Inicializar configuraciones globales aquí
        initializeApp()
    }

    private fun initializeApp() {
        // Aquí puedes inicializar:
        // - SharedPreferences
        // - Base de datos local (Room)
        // - Analytics
        // - Crash reporting
        // - etc.
    }
}