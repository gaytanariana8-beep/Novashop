package com.example.novashop

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import androidx.cardview.widget.CardView
import com.example.ejemplo.R

class AdminPanelActivity : AppCompatActivity() {

    private lateinit var txtTotalSales: AppCompatTextView
    private lateinit var txtTotalRevenue: AppCompatTextView
    private lateinit var txtTotalUsers: AppCompatTextView
    private lateinit var txtPendingOrders: AppCompatTextView
    private lateinit var cardManageProducts: CardView
    private lateinit var cardManageOrders: CardView
    private lateinit var cardManageCustomers: CardView
    private lateinit var cardSalesReport: CardView
    private lateinit var cardInventory: CardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_panel)

        initializeViews()
        loadStatistics()
        setupClickListeners()
    }

    private fun initializeViews() {
        txtTotalSales = findViewById(R.id.txtTotalSales)
        txtTotalRevenue = findViewById(R.id.txtTotalRevenue)
        txtTotalUsers = findViewById(R.id.txtTotalUsers)
        txtPendingOrders = findViewById(R.id.txtPendingOrders)
        cardManageProducts = findViewById(R.id.cardManageProducts)
        cardManageOrders = findViewById(R.id.cardManageOrders)
        cardManageCustomers = findViewById(R.id.cardManageCustomers)
        cardSalesReport = findViewById(R.id.cardSalesReport)
        cardInventory = findViewById(R.id.cardInventory)
    }

    private fun loadStatistics() {
        // Datos de ejemplo
        txtTotalSales.text = "248"
        txtTotalRevenue.text = "$45,890"
        txtTotalUsers.text = "1,234"
        txtPendingOrders.text = "18"
    }

    private fun setupClickListeners() {
        cardManageProducts.setOnClickListener {
            startActivity(Intent(this, ManageProductsActivity::class.java))
        }

        cardManageOrders.setOnClickListener {
            startActivity(Intent(this, ManageOrdersActivity::class.java))
        }

        cardManageCustomers.setOnClickListener {
            startActivity(Intent(this, ManageCustomersActivity::class.java))
        }

        cardSalesReport.setOnClickListener {
            startActivity(Intent(this, SalesReportActivity::class.java))
        }

        cardInventory.setOnClickListener {
            startActivity(Intent(this, InventoryActivity::class.java))
        }
    }
}