package com.example.novashop

import android.os.Bundle
import android.util.Patterns
import android.widget.EditText // Importación añadidaimport android.widget.Toast
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatImageView
import com.example.ejemplo.R

class RecoverPasswordActivity : AppCompatActivity() {

    private lateinit var imgBack: AppCompatImageView
    private lateinit var etRecoverEmail: EditText
    private lateinit var btnSendEmail: AppCompatButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recover_password)

        initializeViews()
        setupClickListeners()
    }

    private fun initializeViews() {
        imgBack = findViewById(R.id.imgBack)
        etRecoverEmail = findViewById(R.id.etRecoverEmail)
        btnSendEmail = findViewById(R.id.btnSendEmail)
    }

    private fun setupClickListeners() {
        imgBack.setOnClickListener {
            finish()
        }

        btnSendEmail.setOnClickListener {
            val email = etRecoverEmail.text.toString().trim()
            if (email.isEmpty()) {
                etRecoverEmail.error = "Ingrese su correo electrónico"
                return@setOnClickListener
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etRecoverEmail.error = "Correo electrónico inválido"
                return@setOnClickListener
            }


            Toast.makeText(
                this,
                "Se ha enviado un enlace de recuperación a tu correo",
                Toast.LENGTH_LONG
            ).show()
            finish()
        }
    }
}
