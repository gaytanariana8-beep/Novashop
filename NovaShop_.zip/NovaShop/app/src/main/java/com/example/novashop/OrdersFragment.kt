package com.example.novashop

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class OrdersFragment : Fragment() {

    private lateinit var rvOrders: RecyclerView
    private lateinit var emptyOrdersLayout: View

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_orders, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initializeViews(view)
        loadOrders()
    }

    private fun initializeViews(view: View) {
        rvOrders = view.findViewById(R.id.rvOrders)
        emptyOrdersLayout = view.findViewById(R.id.emptyOrdersLayout)
    }

    private fun loadOrders() {
        val orders = getSampleOrders()

        if (orders.isEmpty()) {
            emptyOrdersLayout.visibility = View.VISIBLE
            rvOrders.visibility = View.GONE
        } else {
            emptyOrdersLayout.visibility = View.GONE
            rvOrders.visibility = View.VISIBLE

            rvOrders.layoutManager = LinearLayoutManager(requireContext())
            rvOrders.adapter = OrdersAdapter(orders) { order ->
                // Ver detalles del pedido
            }
        }
    }

    private fun getSampleOrders(): List<Order> {
        return listOf(
            Order(
                id = 45678,
                date = "03 Nov 2025",
                status = OrderStatus.IN_PROGRESS,
                total = 964.98,
                items = 2,
                imageUrl = "https://example.com/order1.jpg"
            ),
            Order(
                id = 45123,
                date = "28 Oct 2025",
                status = OrderStatus.DELIVERED,
                total = 299.99,
                items = 1,
                imageUrl = "https://example.com/order2.jpg"
            ),
            Order(
                id = 44890,
                date = "15 Oct 2025",
                status = OrderStatus.DELIVERED,
                total = 549.99,
                items = 3,
                imageUrl = "https://example.com/order3.jpg"
            )
        )
    }
}

data class Order(
    val id: Int,
    val date: String,
    val status: OrderStatus,
    val total: Double,
    val items: Int,
    val imageUrl: String
)

enum class OrderStatus {
    IN_PROGRESS,
    DELIVERED,
    CANCELLED
}