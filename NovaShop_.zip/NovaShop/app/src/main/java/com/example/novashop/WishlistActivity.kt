package com.example.novashop

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class WishlistActivity : AppCompatActivity() {

    private lateinit var rvWishlist: RecyclerView
    private lateinit var emptyWishlistLayout: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wishlist)

        initializeViews()
        loadWishlist()
    }

    private fun initializeViews() {
        rvWishlist = findViewById(R.id.rvWishlist)
        emptyWishlistLayout = findViewById(R.id.emptyWishlistLayout)
    }

    private fun loadWishlist() {
        val wishlistProducts = getWishlistProducts()

        if (wishlistProducts.isEmpty()) {
            emptyWishlistLayout.visibility = View.VISIBLE
            rvWishlist.visibility = View.GONE
        } else {
            emptyWishlistLayout.visibility = View.GONE
            rvWishlist.visibility = View.VISIBLE

            rvWishlist.layoutManager = GridLayoutManager(this, 2)
            rvWishlist.adapter = ProductAdapter(wishlistProducts, true) { product ->
                // Abrir detalle del producto
            }
        }
    }

    private fun getWishlistProducts(): List<Product> {
        // Datos de ejemplo
        return listOf(
            Product(1, "Smartwatch Fit", 249.99, "https://example.com/watch.jpg", 4.6f),
            Product(2, "Cámara Digital HD", 549.99, "https://example.com/camera.jpg", 4.8f),
            Product(3, "Tablet Pro 10", 399.99, "https://example.com/tablet.jpg", 4.4f)
        )
    }
}