
package com.example.novashop

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Toast
import androidx.appcompat.widget.AppCompatTextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class ProductAdapter(
    private val products: List<Product>,
    private val isGrid: Boolean = false,
    private val onProductClick: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    inner class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardProduct: CardView = itemView.findViewById(R.id.cardProduct)
        val imgProduct: ImageView = itemView.findViewById(R.id.imgProduct)
        val txtProductName: AppCompatTextView = itemView.findViewById(R.id.txtProductName)
        val txtPrice: AppCompatTextView = itemView.findViewById(R.id.txtPrice)
        val ratingBar: RatingBar = itemView.findViewById(R.id.ratingBar)
        val btnAddToCart: ImageView = itemView.findViewById(R.id.btnAddToCart)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val layout = if (isGrid) R.layout.item_product_grid else R.layout.item_product_horizontal
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = products[position]

        holder.txtProductName.text = product.name
        holder.txtPrice.text = "$${String.format("%.2f", product.price)}"
        holder.ratingBar.rating = product.rating

        // Cargar imagen (usar Glide o Picasso en proyecto real)
        // Glide.with(holder.itemView.context).load(product.imageUrl).into(holder.imgProduct)

        holder.cardProduct.setOnClickListener {
            onProductClick(product)
        }

        holder.btnAddToCart.setOnClickListener {
            // Agregar al carrito
            Toast.makeText(
                holder.itemView.context,
                "${product.name} agregado al carrito",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun getItemCount(): Int = products.size
}
