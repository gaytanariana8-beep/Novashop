package com.example.novashop


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class ManageOrdersActivity : AppCompatActivity() {

    private lateinit var rvAdminOrders: RecyclerView
    private var orders = mutableListOf<AdminOrder>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_orders)

        initializeViews()
        loadOrders()
    }

    private fun initializeViews() {
        rvAdminOrders = findViewById(R.id.rvAdminOrders)
    }

    private fun loadOrders() {
        orders = mutableListOf(
            AdminOrder(45678, "Juan Pérez", "03 Nov 2025", "En Proceso", 964.98, 2),
            AdminOrder(45677, "María García", "03 Nov 2025", "Pendiente", 549.99, 1),
            AdminOrder(45676, "Carlos López", "02 Nov 2025", "En Proceso", 1299.99, 3),
            AdminOrder(45675, "Ana Martínez", "02 Nov 2025", "Entregado", 299.99, 1),
            AdminOrder(45674, "Luis Rodríguez", "01 Nov 2025", "Entregado", 799.99, 2)
        )

        rvAdminOrders.layoutManager = LinearLayoutManager(this)
        rvAdminOrders.adapter = AdminOrderAdapter(
            orders,
            onApprove = { order -> approveOrder(order) },
            onCancel = { order -> cancelOrder(order) },
            onView = { order -> viewOrderDetails(order) }
        )
    }

    private fun approveOrder(order: AdminOrder) {
        AlertDialog.Builder(this)
            .setTitle("Aprobar Pedido")
            .setMessage("¿Deseas aprobar el pedido #${order.id}?")
            .setPositiveButton("Aprobar") { _, _ ->
                order.status = "Aprobado"
                rvAdminOrders.adapter?.notifyDataSetChanged()
                Toast.makeText(this, "Pedido aprobado", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun cancelOrder(order: AdminOrder) {
        AlertDialog.Builder(this)
            .setTitle("Cancelar Pedido")
            .setMessage("¿Estás seguro de cancelar el pedido #${order.id}?")
            .setPositiveButton("Cancelar Pedido") { _, _ ->
                order.status = "Cancelado"
                rvAdminOrders.adapter?.notifyDataSetChanged()
                Toast.makeText(this, "Pedido cancelado", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("No", null)
            .show()
    }

    private fun viewOrderDetails(order: AdminOrder) {
        val message = """
            Pedido #${order.id}
            Cliente: ${order.customerName}
            Fecha: ${order.date}
            Estado: ${order.status}
            Total: $${String.format("%.2f", order.total)}
            Artículos: ${order.items}
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Detalles del Pedido")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}

data class AdminOrder(
    val id: Int,
    val customerName: String,
    val date: String,
    var status: String,
    val total: Double,
    val items: Int
)

class AdminOrderAdapter(
    private val orders: List<AdminOrder>,
    private val onApprove: (AdminOrder) -> Unit,
    private val onCancel: (AdminOrder) -> Unit,
    private val onView: (AdminOrder) -> Unit
) : RecyclerView.Adapter<AdminOrderAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtOrderId: AppCompatTextView =
            itemView.findViewById(R.id.txtOrderId)
        val txtCustomerName: AppCompatTextView =
            itemView.findViewById(R.id.txtCustomerName)
        val txtOrderDate: AppCompatTextView =
            itemView.findViewById(R.id.txtOrderDate)
        val txtOrderStatus: AppCompatTextView =
            itemView.findViewById(R.id.txtOrderStatus)
        val txtOrderTotal: AppCompatTextView =
            itemView.findViewById(R.id.txtOrderTotal)
        val btnApprove: AppCompatButton =
            itemView.findViewById(R.id.btnApprove)
        val btnCancelOrder: AppCompatButton =
            itemView.findViewById(R.id.btnCancelOrder)
        val btnViewDetails: AppCompatButton =
            itemView.findViewById(R.id.btnViewDetails)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_admin_order, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val order = orders[position]

        holder.txtOrderId.text = "Pedido #${order.id}"
        holder.txtCustomerName.text = order.customerName
        holder.txtOrderDate.text = order.date
        holder.txtOrderStatus.text = order.status
        holder.txtOrderTotal.text = "$${String.format("%.2f", order.total)}"

        holder.btnApprove.setOnClickListener { onApprove(order) }
        holder.btnCancelOrder.setOnClickListener { onCancel(order) }
        holder.btnViewDetails.setOnClickListener { onView(order) }
    }

    override fun getItemCount(): Int = orders.size
}