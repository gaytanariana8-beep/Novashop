package com.example.novashop.network

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object ApiService {


    private const val BASE_URL = "http://192.168.1.6/novashop/api"


    data class ApiResponse(
        val success: Boolean,
        val message: String,
        val data: JSONObject? = null,
        val errors: List<String>? = null
    )

    //Conexion
    suspend fun testConnection(): ApiResponse = withContext(Dispatchers.IO) {
        try {
            val url = URL("$BASE_URL/test.php")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 10000
            connection.readTimeout = 10000

            val responseCode = connection.responseCode
            val response = readResponse(connection)

            Log.d("ApiService", "Test Response: $response")

            if (responseCode == 200) {
                parseResponse(response)
            } else {
                ApiResponse(false, "Error de conexión: Código $responseCode")
            }
        } catch (e: Exception) {
            Log.e("ApiService", "Error en testConnection", e)
            ApiResponse(false, "Error: ${e.message}")
        }
    }

    // Registro de usuario
    suspend fun registerUser(
        nombre: String,
        apellido: String,
        email: String,
        password: String
    ): ApiResponse = withContext(Dispatchers.IO) {
        try {
            val url = URL("$BASE_URL/register.php")
            val connection = url.openConnection() as HttpURLConnection

            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.doOutput = true
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            // Crear JSON con los datos
            val jsonData = JSONObject().apply {
                put("nombre", nombre)
                put("apellido", apellido)
                put("email", email)
                put("password", password)
            }

            // Enviar datos
            val writer = OutputStreamWriter(connection.outputStream)
            writer.write(jsonData.toString())
            writer.flush()
            writer.close()

            val responseCode = connection.responseCode
            val response = readResponse(connection)

            Log.d("ApiService", "Register Response: $response")

            parseResponse(response)
        } catch (e: Exception) {
            Log.e("ApiService", "Error en registerUser", e)
            ApiResponse(false, "Error de conexión: ${e.message}")
        }
    }

    // Login de usuario
    suspend fun loginUser(email: String, password: String): ApiResponse =
        withContext(Dispatchers.IO) {
            try {
                val url = URL("$BASE_URL/login.php")
                val connection = url.openConnection() as HttpURLConnection

                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true
                connection.connectTimeout = 15000
                connection.readTimeout = 15000

                // Crear JSON con las credenciales
                val jsonData = JSONObject().apply {
                    put("email", email)
                    put("password", password)
                }

                // Enviar datos
                val writer = OutputStreamWriter(connection.outputStream)
                writer.write(jsonData.toString())
                writer.flush()
                writer.close()

                val responseCode = connection.responseCode
                val response = readResponse(connection)

                Log.d("ApiService", "Login Response: $response")

                parseResponse(response)
            } catch (e: Exception) {
                Log.e("ApiService", "Error en loginUser", e)
                ApiResponse(false, "Error de conexión: ${e.message}")
            }
        }

    // Leer respuesta del servidor
    private fun readResponse(connection: HttpURLConnection): String {
        return try {
            val inputStream = if (connection.responseCode < 400) {
                connection.inputStream
            } else {
                connection.errorStream
            }

            val reader = BufferedReader(InputStreamReader(inputStream))
            val response = StringBuilder()
            var line: String?

            while (reader.readLine().also { line = it } != null) {
                response.append(line)
            }

            reader.close()
            response.toString()
        } catch (e: Exception) {
            ""
        }
    }

    // Obtener productos
    suspend fun getProducts(
        type: String = "all",
        categoryId: Int? = null,
        limit: Int = 20,
        offset: Int = 0
    ): ApiResponse = withContext(Dispatchers.IO) {
        try {
            var url = "$BASE_URL/products.php?type=$type&limit=$limit&offset=$offset"
            if (categoryId != null) {
                url += "&category_id=$categoryId"
            }

            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 10000
            connection.readTimeout = 10000

            val responseCode = connection.responseCode
            val response = readResponse(connection)

            Log.d("ApiService", "Products Response: $response")

            parseResponse(response)
        } catch (e: Exception) {
            Log.e("ApiService", "Error en getProducts", e)
            ApiResponse(false, "Error: ${e.message}")
        }
    }

    // Obtener categorías
    suspend fun getCategories(): ApiResponse = withContext(Dispatchers.IO) {
        try {
            val url = URL("$BASE_URL/categories.php")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 10000
            connection.readTimeout = 10000

            val responseCode = connection.responseCode
            val response = readResponse(connection)

            Log.d("ApiService", "Categories Response: $response")

            parseResponse(response)
        } catch (e: Exception) {
            Log.e("ApiService", "Error en getCategories", e)
            ApiResponse(false, "Error: ${e.message}")
        }
    }

    // Obtener detalle de producto
    suspend fun getProductDetail(productId: Int): ApiResponse =
        withContext(Dispatchers.IO) {
            try {
                val url = URL("$BASE_URL/product_detail.php?id=$productId")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000

                val responseCode = connection.responseCode
                val response = readResponse(connection)

                Log.d("ApiService", "Product Detail Response: $response")

                parseResponse(response)
            } catch (e: Exception) {
                Log.e("ApiService", "Error en getProductDetail", e)
                ApiResponse(false, "Error: ${e.message}")
            }
        }

    // Parsear respuesta JSON
    private fun parseResponse(jsonString: String): ApiResponse {
        return try {
            val json = JSONObject(jsonString)
            val success = json.optBoolean("success", false)
            val message = json.optString("message", "Sin mensaje")
            val data = json.optJSONObject("data")
            val errorsArray = json.optJSONArray("errors")

            val errors = if (errorsArray != null) {
                List(errorsArray.length()) { i ->
                    errorsArray.getString(i)
                }
            } else null

            ApiResponse(success, message, data, errors)
        } catch (e: Exception) {
            Log.e("ApiService", "Error al parsear JSON", e)
            ApiResponse(false, "Error al procesar respuesta del servidor")
        }
    }
}