
package com.example.novashop


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class CategoryAdapter(
    private val categories: List<com.example.novashop.Category>,
    private val onCategoryClick: (Category) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    inner class CategoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardCategory: CardView = itemView.findViewById(R.id.cardCategory)
        val imgCategory: ImageView = itemView.findViewById(R.id.imgCategory)
        val txtCategoryName: AppCompatTextView = itemView.findViewById(R.id.txtCategoryName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category, parent, false)
        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categories[position]

        holder.txtCategoryName.text = category.name

        // Establecer el icono según la categoría
        val iconResId = holder.itemView.context.resources.getIdentifier(
            category.icon,
            "drawable",
            holder.itemView.context.packageName
        )

        if (iconResId != 0) {
            holder.imgCategory.setImageResource(iconResId)
        }

        holder.cardCategory.setOnClickListener {
            onCategoryClick(category)
        }
    }

    override fun getItemCount(): Int = categories.size
}
