package com.example.novashop

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import com.example.ejemplo.R

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var imgProduct: ImageView
    private lateinit var txtProductName: AppCompatTextView
    private lateinit var txtPrice: AppCompatTextView
    private lateinit var txtDescription: AppCompatTextView
    private lateinit var ratingBar: RatingBar
    private lateinit var txtRating: AppCompatTextView
    private lateinit var btnAddToCart: AppCompatButton
    private lateinit var btnBuyNow: AppCompatButton
    private lateinit var btnBack: ImageView
    private lateinit var btnFavorite: ImageView

    private var isFavorite = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        initializeViews()
        loadProductData()
        setupClickListeners()
    }

    private fun initializeViews() {
        imgProduct = findViewById(R.id.imgProduct)
        txtProductName = findViewById(R.id.txtProductName)
        txtPrice = findViewById(R.id.txtPrice)
        txtDescription = findViewById(R.id.txtDescription)
        ratingBar = findViewById(R.id.ratingBar)
        txtRating = findViewById(R.id.txtRating)
        btnAddToCart = findViewById(R.id.btnAddToCart)
        btnBuyNow = findViewById(R.id.btnBuyNow)
        btnBack = findViewById(R.id.btnBack)
        btnFavorite = findViewById(R.id.btnFavorite)
    }

    private fun loadProductData() {
        val productId = intent.getIntExtra("PRODUCT_ID", 0)

        // Datos de ejemplo
        txtProductName.text = "Smartphone XZ Pro"
        txtPrice.text = "$799.99"
        txtDescription.text = "Smartphone de última generación con pantalla AMOLED de 6.5 pulgadas, procesador octa-core, 8GB RAM, 128GB almacenamiento, cámara triple de 48MP y batería de 5000mAh."
        ratingBar.rating = 4.5f
        txtRating.text = "4.5 (342 reseñas)"
    }

    private fun setupClickListeners() {
        btnBack.setOnClickListener {
            finish()
        }

        btnFavorite.setOnClickListener {
            isFavorite = !isFavorite
            if (isFavorite) {
                btnFavorite.setImageResource(R.drawable.ic_favorite_filled)
                Toast.makeText(this, "Agregado a favoritos", Toast.LENGTH_SHORT).show()
            } else {
                btnFavorite.setImageResource(R.drawable.ic_favorite)
                Toast.makeText(this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show()

                startActivity(Intent(this@ProductDetailActivity, WishlistActivity::class.java))
                finish()
            }
        }

        btnAddToCart.setOnClickListener {
            Toast.makeText(this, "Producto agregado al carrito", Toast.LENGTH_SHORT).show()
        }

        btnBuyNow.setOnClickListener {
            Toast.makeText(this, "Procediendo al pago", Toast.LENGTH_SHORT).show()
        }
    }
}