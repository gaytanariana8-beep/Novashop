package com.example.novashop

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import androidx.appcompat.widget.AppCompatTextView
import androidx.lifecycle.lifecycleScope
import com.example.ejemplo.R
import com.example.novashop.network.ApiService
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var etEmail: AppCompatEditText
    private lateinit var etPassword: AppCompatEditText
    private lateinit var btnLogin: AppCompatButton
    private lateinit var txtForgotPassword: AppCompatTextView
    private lateinit var txtSignUp: AppCompatTextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        initializeViews()
        setupClickListeners()

        // Probar conexión al iniciar
        testApiConnection()
    }

    private fun initializeViews() {
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtSignUp = findViewById(R.id.txtSignUp)
    }

    private fun setupClickListeners() {
        btnLogin.setOnClickListener {
            validateAndLogin()
        }

        txtSignUp.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }

        txtForgotPassword.setOnClickListener {
            Toast.makeText(
                this,
                "Función en desarrollo",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun testApiConnection() {
        lifecycleScope.launch {
            val response = ApiService.testConnection()
            if (response.success) {
                Toast.makeText(
                    this@LoginActivity,
                    "Conectado al servidor",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun validateAndLogin() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()

        // Validaciones
        if (email.isEmpty()) {
            etEmail.error = "Ingrese su correo electrónico"
            etEmail.requestFocus()
            return
        }

        if (password.isEmpty()) {
            etPassword.error = "Ingrese su contraseña"
            etPassword.requestFocus()
            return
        }

        // Deshabilitar botón mientras se procesa
        btnLogin.isEnabled = false
        btnLogin.text = "Iniciando sesión..."

        lifecycleScope.launch {
            val response = ApiService.loginUser(email, password)

            runOnUiThread {
                btnLogin.isEnabled = true
                btnLogin.text = "Iniciar Sesión"

                if (response.success) {
                    val userData = response.data
                    val nombreCompleto = userData?.optString("nombre_completo", "Usuario")

                    Toast.makeText(
                        this@LoginActivity,
                        "¡Bienvenido $nombreCompleto!",
                        Toast.LENGTH_LONG
                    ).show()

                    // Limpiar campos
                    etEmail.text?.clear()
                    etPassword.text?.clear()

                    startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(
                        this@LoginActivity,
                        response.message,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }
}