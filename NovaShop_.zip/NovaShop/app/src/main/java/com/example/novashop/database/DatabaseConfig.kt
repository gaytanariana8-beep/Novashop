package com.example.novashop.database

import android.os.Build

object DatabaseConfig {
    private const val HOST_PHYSICAL = "192.168.1.6"
    private const val HOST_EMULATOR = "10.0.2.2"

    private const val PORT = "3306"
    private const val DATABASE = "novashop_offline"
    private const val USER = "novashop_offline"
    private const val PASS = "NovaShopOffile2025!"

    val HOST: String
        get() = if (Build.FINGERPRINT.contains("generic")) {
            HOST_EMULATOR
        } else {
            HOST_PHYSICAL
        }

    fun getUrl() = "jdbc:mysql://$HOST:$PORT/$DATABASE?useSSL=false"
    fun getUser() = USER
    fun getPass() = PASS
}