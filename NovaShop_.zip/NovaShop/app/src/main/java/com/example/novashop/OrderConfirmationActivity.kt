package com.example.novashop


import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import com.example.ejemplo.R

class OrderConfirmationActivity : AppCompatActivity() {

    private lateinit var txtOrderNumber: AppCompatTextView
    private lateinit var txtConfirmationMessage: AppCompatTextView
    private lateinit var btnViewOrders: AppCompatButton
    private lateinit var btnContinueShopping: AppCompatButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_confirmation)

        val orderNumber = intent.getIntExtra("ORDER_NUMBER", 0)

        initializeViews()
        displayOrderInfo(orderNumber)
        setupClickListeners()
    }

    private fun initializeViews() {
        txtOrderNumber = findViewById(R.id.txtOrderNumber)
        txtConfirmationMessage = findViewById(R.id.txtConfirmationMessage)
        btnViewOrders = findViewById(R.id.btnViewOrders)
        btnContinueShopping = findViewById(R.id.btnContinueShopping)
    }

    private fun displayOrderInfo(orderNumber: Int) {
        txtOrderNumber.text = "Pedido #$orderNumber"
        txtConfirmationMessage.text = "Tu pedido ha sido realizado exitosamente. " +
                "Recibirás un correo de confirmación con los detalles de tu compra."
    }

    private fun setupClickListeners() {
        btnViewOrders.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            intent.putExtra("NAVIGATE_TO", "orders")
            startActivity(intent)
            finish()
        }

        btnContinueShopping.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
    }
}