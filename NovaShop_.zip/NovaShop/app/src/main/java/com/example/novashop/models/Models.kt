package com.example.novashop.models

import org.json.JSONObject

/**
 * Modelo de Producto
 */
data class Product(
    val id: Int,
    val name: String,
    val description: String?,
    val price: Double,
    val originalPrice: Double?,
    val categoryId: Int,
    val categoryName: String,
    val imageUrl: String,
    val stock: Int,
    val brand: String?,
    val rating: Float,
    val totalReviews: Int,
    val featured: Boolean,
    val offer: Boolean
) {
    companion object {
        fun fromJson(json: JSONObject): Product {
            return Product(
                id = json.optInt("id", 0),
                name = json.optString("name", ""),
                description = json.optString("description", null),
                price = json.optDouble("price", 0.0),
                originalPrice = if (json.has("original_price") && !json.isNull("original_price"))
                    json.optDouble("original_price") else null,
                categoryId = json.optInt("categoria_id", 0),
                categoryName = json.optString("category_name", ""),
                imageUrl = json.optString("imageUrl", ""),
                stock = json.optInt("stock", 0),
                brand = json.optString("brand", null),
                rating = json.optDouble("rating", 0.0).toFloat(),
                totalReviews = json.optInt("totalReviews", 0),
                featured = json.optInt("featured", 0) == 1,
                offer = json.optInt("offer", 0) == 1
            )
        }
    }

    fun hasDiscount(): Boolean = originalPrice != null && originalPrice > price

    fun getDiscountPercentage(): Int {
        return if (hasDiscount()) {
            (((originalPrice!! - price) / originalPrice) * 100).toInt()
        } else 0
    }
}

/**
 * Modelo de Categoría
 */
data class Category(
    val id: Int,
    val name: String,
    val description: String?,
    val icon: String,
    val imageUrl: String?,
    val productCount: Int
) {
    companion object {
        fun fromJson(json: JSONObject): Category {
            return Category(
                id = json.optInt("id", 0),
                name = json.optString("name", ""),
                description = json.optString("description", null),
                icon = json.optString("icon", "ic_category"),
                imageUrl = json.optString("imageUrl", null),
                productCount = json.optInt("product_count", 0)
            )
        }
    }
}

/**
 * Modelo de Review
 */
data class Review(
    val id: Int,
    val rating: Float,
    val title: String?,
    val comment: String?,
    val date: String,
    val verified: Boolean,
    val userName: String
) {
    companion object {
        fun fromJson(json: JSONObject): Review {
            return Review(
                id = json.optInt("id", 0),
                rating = json.optDouble("rating", 0.0).toFloat(),
                title = json.optString("title", null),
                comment = json.optString("comment", null),
                date = json.optString("date", ""),
                verified = json.optInt("verified", 0) == 1,
                userName = json.optString("user_name", "Usuario")
            )
        }
    }
}

/**
 * Modelo de Usuario
 */
data class User(
    val id: Int,
    val nombre: String,
    val apellido: String,
    val email: String,
    val tipoUsuario: String = "cliente"
) {
    companion object {
        fun fromJson(json: JSONObject): User {
            return User(
                id = json.optInt("id", 0),
                nombre = json.optString("nombre", ""),
                apellido = json.optString("apellido", ""),
                email = json.optString("email", ""),
                tipoUsuario = json.optString("tipo_usuario", "cliente")
            )
        }
    }

    fun getNombreCompleto(): String = "$nombre $apellido"
    fun isAdmin(): Boolean = tipoUsuario == "admin"
}

/**
 * Modelo de Item del Carrito
 */
data class CartItem(
    val id: Int,
    val product: Product,
    val quantity: Int,
    val unitPrice: Double
) {
    fun getSubtotal(): Double = unitPrice * quantity
}

/**
 * Modelo de Pedido
 */
data class Order(
    val id: Int,
    val orderNumber: String,
    val total: Double,
    val status: String,
    val orderDate: String,
    val items: List<OrderItem>
)

/**
 * Modelo de Item de Pedido
 */
data class OrderItem(
    val productName: String,
    val quantity: Int,
    val unitPrice: Double,
    val subtotal: Double
)