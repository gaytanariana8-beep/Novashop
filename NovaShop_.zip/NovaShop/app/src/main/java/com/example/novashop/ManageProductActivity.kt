package com.example.novashop


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ManageProductsActivity : AppCompatActivity() {

    private lateinit var rvAdminProducts: RecyclerView
    private lateinit var fabAddProduct: FloatingActionButton
    private var products = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_products)

        initializeViews()
        loadProducts()
        setupClickListeners()
    }

    private fun initializeViews() {
        rvAdminProducts = findViewById(R.id.rvAdminProducts)
        fabAddProduct = findViewById(R.id.fabAddProduct)
    }

    private fun loadProducts() {
        products = mutableListOf(
            Product(1, "Smartphone XZ Pro", 799.99, "https://example.com/phone.jpg", 4.5f),
            Product(2, "Laptop Ultra 15", 1299.99, "https://example.com/laptop.jpg", 4.7f),
            Product(3, "Auriculares Wireless", 149.99, "https://example.com/headphones.jpg", 4.3f),
            Product(4, "Smartwatch Fit", 249.99, "https://example.com/watch.jpg", 4.6f),
            Product(5, "Tablet Pro 10", 399.99, "https://example.com/tablet.jpg", 4.4f)
        )

        rvAdminProducts.layoutManager = LinearLayoutManager(this)
        rvAdminProducts.adapter = AdminProductAdapter(
            products,
            onEdit = { product -> editProduct(product) },
            onDelete = { product -> deleteProduct(product) }
        )
    }

    private fun setupClickListeners() {
        fabAddProduct.setOnClickListener {
            // Abrir activity para agregar producto
            Toast.makeText(this, "Agregar nuevo producto", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editProduct(product: Product) {
        Toast.makeText(this, "Editar: ${product.name}", Toast.LENGTH_SHORT).show()
        // Abrir activity para editar producto
    }

    private fun deleteProduct(product: Product) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar Producto")
            .setMessage("¿Estás seguro de que deseas eliminar ${product.name}?")
            .setPositiveButton("Eliminar") { _, _ ->
                products.remove(product)
                rvAdminProducts.adapter?.notifyDataSetChanged()
                Toast.makeText(this, "Producto eliminado", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}

class AdminProductAdapter(
    private val products: List<Product>,
    private val onEdit: (Product) -> Unit,
    private val onDelete: (Product) -> Unit
) : RecyclerView.Adapter<AdminProductAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtProductName: AppCompatTextView =
            itemView.findViewById(R.id.txtProductName)
        val txtProductPrice: AppCompatTextView =
            itemView.findViewById(R.id.txtProductPrice)
        val btnEdit: AppCompatButton = itemView.findViewById(R.id.btnEdit)
        val btnDelete: AppCompatButton = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_admin_product, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val product = products[position]
        holder.txtProductName.text = product.name
        holder.txtProductPrice.text = "$${String.format("%.2f", product.price)}"

        holder.btnEdit.setOnClickListener { onEdit(product) }
        holder.btnDelete.setOnClickListener { onDelete(product) }
    }

    override fun getItemCount(): Int = products.size
}