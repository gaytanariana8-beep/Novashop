package com.example.novashop


import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.AppCompatTextView
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import com.example.ejemplo.R

class ProfileFragment : Fragment() {

    private lateinit var imgProfilePhoto: ImageView
    private lateinit var txtUserName: AppCompatTextView
    private lateinit var txtUserEmail: AppCompatTextView
    private lateinit var cardPersonalInfo: CardView
    private lateinit var cardChangePassword: CardView
    private lateinit var cardWishlist: CardView
    private lateinit var cardAddresses: CardView
    private lateinit var cardPaymentMethods: CardView
    private lateinit var cardNotifications: CardView
    private lateinit var cardHelp: CardView
    private lateinit var cardLogout: CardView

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val imageUri = data?.data
            imgProfilePhoto.setImageURI(imageUri)
            Toast.makeText(requireContext(), "Foto actualizada", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initializeViews(view)
        loadUserData()
        setupClickListeners()
    }

    private fun initializeViews(view: View) {
        imgProfilePhoto = view.findViewById(R.id.imgProfilePhoto)
        txtUserName = view.findViewById(R.id.txtUserName)
        txtUserEmail = view.findViewById(R.id.txtUserEmail)
        cardPersonalInfo = view.findViewById(R.id.cardPersonalInfo)
        cardChangePassword = view.findViewById(R.id.cardChangePassword)
        cardWishlist = view.findViewById(R.id.cardWishlist)
        cardAddresses = view.findViewById(R.id.cardAddresses)
        cardPaymentMethods = view.findViewById(R.id.cardPaymentMethods)
        cardNotifications = view.findViewById(R.id.cardNotifications)
        cardHelp = view.findViewById(R.id.cardHelp)
        cardLogout = view.findViewById(R.id.cardLogout)
    }

    private fun loadUserData() {
        txtUserName.text = "Juan Pérez"
        txtUserEmail.text = "juan.perez@email.com"
    }

    private fun setupClickListeners() {
        imgProfilePhoto.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            imagePickerLauncher.launch(intent)
        }

        cardPersonalInfo.setOnClickListener {
            startActivity(Intent(requireContext(), PersonalInfoActivity::class.java))
        }


        cardChangePassword.setOnClickListener {
            startActivity(Intent(requireContext(), ChangePasswordActivity::class.java))
        }

        cardWishlist.setOnClickListener {
            startActivity(Intent(requireContext(), WishlistActivity::class.java))
        }

        cardAddresses.setOnClickListener {
            Toast.makeText(requireContext(), "Direcciones guardadas", Toast.LENGTH_SHORT).show()
        }

        cardPaymentMethods.setOnClickListener {
            Toast.makeText(requireContext(), "Métodos de pago", Toast.LENGTH_SHORT).show()
        }

        cardNotifications.setOnClickListener {
            Toast.makeText(requireContext(), "Configuración de notificaciones", Toast.LENGTH_SHORT).show()
        }

        cardHelp.setOnClickListener {
            Toast.makeText(requireContext(), "Centro de ayuda", Toast.LENGTH_SHORT).show()
        }

        cardLogout.setOnClickListener {
            logout()
        }
    }

    private fun logout() {
        Toast.makeText(requireContext(), "Sesión cerrada", Toast.LENGTH_SHORT).show()
        val intent = Intent(requireContext(), LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }
}