package com.example.novashop.database

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.DriverManager
import java.sql.DriverManager.getConnection

object DatabaseConnection {

    suspend fun getConnection(): Connection? = withContext(Dispatchers.IO) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver")
            getConnection(
                DatabaseConfig.getUrl(),
                DatabaseConfig.getUser(),
                DatabaseConfig.getPass()
            )
        } catch (e: Exception) {
            Log.e("DB", "Error: ${e.message}")
            null
        }
    }

    suspend fun testConnection(): Boolean = withContext(Dispatchers.IO) {
        val conn = getConnection()
        val ok = conn != null
        conn?.close()
        ok
    }
}