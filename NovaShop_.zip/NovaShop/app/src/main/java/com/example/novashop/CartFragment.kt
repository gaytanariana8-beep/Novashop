package com.example.novashop

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ejemplo.R

class CartFragment : Fragment() {

    private lateinit var rvCartItems: RecyclerView
    private lateinit var txtSubtotal: AppCompatTextView
    private lateinit var txtShipping: AppCompatTextView
    private lateinit var txtTotal: AppCompatTextView
    private lateinit var btnCheckout: AppCompatButton
    private lateinit var emptyCartLayout: View
    private lateinit var cartLayout: View

    private var cartItems = mutableListOf<CartItem>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_cart, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initializeViews(view)
        loadCartItems()
        setupRecyclerView()
        updateTotals()
    }

    private fun initializeViews(view: View) {
        rvCartItems = view.findViewById(R.id.rvCartItems)
        txtSubtotal = view.findViewById(R.id.txtSubtotal)
        txtShipping = view.findViewById(R.id.txtShipping)
        txtTotal = view.findViewById(R.id.txtTotal)
        btnCheckout = view.findViewById(R.id.btnCheckout)
        emptyCartLayout = view.findViewById(R.id.emptyCartLayout)
        cartLayout = view.findViewById(R.id.cartLayout)

        btnCheckout.setOnClickListener {
            if (cartItems.isNotEmpty()) {
                val intent = Intent(requireContext(), CheckoutActivity::class.java)
                startActivity(intent)
            }
        }
    }

    private fun loadCartItems() {
        // Datos de ejemplo
        cartItems = mutableListOf(
            CartItem(1, "Smartphone XZ Pro", 799.99, 1, "https://example.com/phone.jpg"),
            CartItem(2, "Auriculares Wireless", 149.99, 2, "https://example.com/headphones.jpg")
        )

        if (cartItems.isEmpty()) {
            emptyCartLayout.visibility = View.VISIBLE
            cartLayout.visibility = View.GONE
        } else {
            emptyCartLayout.visibility = View.GONE
            cartLayout.visibility = View.VISIBLE
        }
    }

    private fun setupRecyclerView() {
        rvCartItems.layoutManager = LinearLayoutManager(requireContext())
        rvCartItems.adapter = CartAdapter(cartItems,
            onQuantityChanged = { updateTotals() },
            onItemRemoved = { item ->
                cartItems.remove(item)
                rvCartItems.adapter?.notifyDataSetChanged()
                updateTotals()

                if (cartItems.isEmpty()) {
                    emptyCartLayout.visibility = View.VISIBLE
                    cartLayout.visibility = View.GONE
                }
            }
        )
    }

    private fun updateTotals() {
        val subtotal = cartItems.sumOf { it.price * it.quantity }
        val shipping = if (subtotal > 0) 15.00 else 0.0
        val total = subtotal + shipping

        txtSubtotal.text = "$${"%.2f".format(subtotal)}"
        txtShipping.text = "$${"%.2f".format(shipping)}"
        txtTotal.text = "$${"%.2f".format(total)}"
    }
}

data class CartItem(
    val id: Int,
    val name: String,
    val price: Double,
    var quantity: Int,
    val imageUrl: String
)